
  # Kids Exam Prep App

  This is a code bundle for Kids Exam Prep App. The original project is available at https://www.figma.com/design/ZPlI6otBqeCHhM8y476znF/Kids-Exam-Prep-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  