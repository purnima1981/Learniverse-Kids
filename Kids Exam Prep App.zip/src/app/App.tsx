import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  RadarChart, Radar, PolarGrid, PolarAngleAxis,
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  LineChart, Line, CartesianGrid, Legend,
} from "recharts";
import {
  Trophy, Star, Clock, Zap, BookOpen, FlaskConical,
  Calculator, Brain, ChevronRight, ChevronLeft, Check,
  X, BarChart2, Users, LogOut, Plus, ArrowRight,
  Sparkles, Target, TrendingUp, Medal, Timer,
} from "lucide-react";

// ─── Types ───────────────────────────────────────────────────────────────────

type View =
  | "landing"
  | "parent-auth"
  | "parent-dashboard"
  | "kid-select"
  | "kid-dashboard"
  | "practice-test"
  | "test-results"
  | "add-kid";

interface Kid {
  id: string;
  name: string;
  grade: number;
  avatar: string;
  totalTests: number;
  avgScore: number;
  streak: number;
  xp: number;
}

interface Question {
  id: number;
  question: string;
  options: string[];
  correct: number;
  topic: string;
  bloomLevel: "Remember" | "Understand" | "Apply" | "Analyze";
  difficulty: "Easy" | "Medium" | "Hard";
  timeAllotted: number;
}

interface TestResult {
  questionId: number;
  selected: number | null;
  correct: boolean;
  timeTaken: number;
  topic: string;
  bloomLevel: string;
}

// ─── Data ────────────────────────────────────────────────────────────────────

const KIDS: Kid[] = [
  { id: "k1", name: "Priya", grade: 5, avatar: "🦊", totalTests: 14, avgScore: 82, streak: 5, xp: 1240 },
  { id: "k2", name: "Aryan", grade: 7, avatar: "🦁", totalTests: 9, avgScore: 74, streak: 2, xp: 890 },
];

const MATH_QUESTIONS: Question[] = [
  {
    id: 1,
    question: "A train travels 240 km in 3 hours. What is its average speed in km/h?",
    options: ["60", "70", "80", "90"],
    correct: 2,
    topic: "Speed & Distance",
    bloomLevel: "Apply",
    difficulty: "Easy",
    timeAllotted: 45,
  },
  {
    id: 2,
    question: "What is the LCM of 12, 18, and 24?",
    options: ["36", "48", "72", "96"],
    correct: 2,
    topic: "Number Theory",
    bloomLevel: "Remember",
    difficulty: "Easy",
    timeAllotted: 40,
  },
  {
    id: 3,
    question: "If 3x + 7 = 22, what is x?",
    options: ["3", "4", "5", "6"],
    correct: 2,
    topic: "Algebra",
    bloomLevel: "Apply",
    difficulty: "Medium",
    timeAllotted: 50,
  },
  {
    id: 4,
    question: "A rectangle has area 84 cm² and width 7 cm. What is its perimeter?",
    options: ["38 cm", "46 cm", "50 cm", "54 cm"],
    correct: 1,
    topic: "Geometry",
    bloomLevel: "Analyze",
    difficulty: "Medium",
    timeAllotted: 60,
  },
  {
    id: 5,
    question: "The average of five numbers is 18. If four of them are 14, 20, 16, and 22, what is the fifth?",
    options: ["16", "18", "20", "22"],
    correct: 1,
    topic: "Statistics",
    bloomLevel: "Analyze",
    difficulty: "Hard",
    timeAllotted: 70,
  },
];

const SCIENCE_QUESTIONS: Question[] = [
  {
    id: 6,
    question: "Which organelle is called the 'powerhouse of the cell'?",
    options: ["Nucleus", "Ribosome", "Mitochondria", "Golgi body"],
    correct: 2,
    topic: "Cell Biology",
    bloomLevel: "Remember",
    difficulty: "Easy",
    timeAllotted: 30,
  },
  {
    id: 7,
    question: "A ball is thrown upward. At its highest point, its velocity is:",
    options: ["Maximum", "Zero", "Equal to initial", "Negative"],
    correct: 1,
    topic: "Physics",
    bloomLevel: "Understand",
    difficulty: "Medium",
    timeAllotted: 45,
  },
  {
    id: 8,
    question: "Which gas is produced during photosynthesis?",
    options: ["Carbon Dioxide", "Nitrogen", "Oxygen", "Hydrogen"],
    correct: 2,
    topic: "Botany",
    bloomLevel: "Remember",
    difficulty: "Easy",
    timeAllotted: 30,
  },
  {
    id: 9,
    question: "Why does ice float on water?",
    options: [
      "Ice is colder than water",
      "Ice is less dense than liquid water",
      "Water repels ice",
      "Ice has more mass",
    ],
    correct: 1,
    topic: "Chemistry",
    bloomLevel: "Understand",
    difficulty: "Medium",
    timeAllotted: 50,
  },
  {
    id: 10,
    question: "If a plant is kept in darkness for several days, which process would stop first?",
    options: ["Respiration", "Photosynthesis", "Transpiration", "Absorption"],
    correct: 1,
    topic: "Botany",
    bloomLevel: "Analyze",
    difficulty: "Hard",
    timeAllotted: 65,
  },
];

const BLOOM_COLORS: Record<string, string> = {
  Remember: "#06b6d4",
  Understand: "#22c55e",
  Apply: "#f97316",
  Analyze: "#8b5cf6",
  Evaluate: "#f59e0b",
  Create: "#ec4899",
};

const SUBJECT_CONFIGS = [
  { id: "math", label: "Math Olympiad", icon: Calculator, color: "#f97316", bg: "bg-orange-50", questions: MATH_QUESTIONS },
  { id: "science", label: "Science", icon: FlaskConical, color: "#06b6d4", bg: "bg-cyan-50", questions: SCIENCE_QUESTIONS },
];

const PROGRESS_DATA = [
  { week: "Wk 1", math: 62, science: 55 },
  { week: "Wk 2", math: 70, science: 64 },
  { week: "Wk 3", math: 75, science: 71 },
  { week: "Wk 4", math: 82, science: 78 },
];

const TOPIC_RADAR = [
  { topic: "Algebra", score: 85 },
  { topic: "Geometry", score: 72 },
  { topic: "Number Theory", score: 90 },
  { topic: "Statistics", score: 65 },
  { topic: "Speed/Distance", score: 80 },
];

const BLOOM_DATA = [
  { level: "Remember", score: 92 },
  { level: "Understand", score: 85 },
  { level: "Apply", score: 74 },
  { level: "Analyze", score: 61 },
];

// ─── Helpers ─────────────────────────────────────────────────────────────────

function formatTime(seconds: number) {
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return m > 0 ? `${m}m ${s}s` : `${s}s`;
}

function Badge({ label, color }: { label: string; color: string }) {
  return (
    <span
      className="inline-block px-2 py-0.5 rounded-full text-xs font-bold text-white"
      style={{ backgroundColor: color }}
    >
      {label}
    </span>
  );
}

// ─── Landing ─────────────────────────────────────────────────────────────────

function LandingView({ onEnter }: { onEnter: () => void }) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-[#fdf6ee] via-[#fff7ed] to-[#eff6ff] flex flex-col">
      {/* Nav */}
      <nav className="flex items-center justify-between px-8 py-5">
        <div className="flex items-center gap-2">
          <span className="text-3xl">🚀</span>
          <span className="font-black text-xl tracking-tight" style={{ fontFamily: "'Fredoka One', cursive" }}>
            BrainSpark
          </span>
        </div>
        <button
          onClick={onEnter}
          className="bg-primary text-white px-5 py-2 rounded-full text-sm font-bold hover:bg-orange-600 transition-colors"
        >
          Sign In
        </button>
      </nav>

      {/* Hero */}
      <div className="flex-1 flex flex-col items-center justify-center text-center px-6 pt-8 pb-16 gap-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-2xl"
        >
          <div className="inline-flex items-center gap-2 bg-orange-100 text-orange-700 px-4 py-1.5 rounded-full text-sm font-bold mb-6">
            <Sparkles size={14} /> For Grades 3–8 · Math & Science Olympiads
          </div>
          <h1
            className="text-5xl md:text-6xl font-black leading-tight mb-4 text-[#1e1a14]"
            style={{ fontFamily: "'Fredoka One', cursive" }}
          >
            Learn Smarter,<br />
            <span className="text-primary">Compete Better</span>
          </h1>
          <p className="text-lg text-[#7c6a55] max-w-xl mx-auto leading-relaxed">
            Timed practice tests aligned to Math Olympiad & Science competitions.
            Parents track every detail. Kids level up with every attempt.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.5 }}
          className="flex flex-col sm:flex-row gap-4"
        >
          <button
            onClick={onEnter}
            className="flex items-center gap-2 bg-primary text-white px-8 py-4 rounded-2xl text-lg font-bold hover:bg-orange-600 transition-all hover:scale-105 shadow-lg shadow-orange-200"
          >
            Start for Free <ArrowRight size={20} />
          </button>
          <button className="flex items-center gap-2 bg-white text-[#1e1a14] px-8 py-4 rounded-2xl text-lg font-bold border border-[rgba(120,90,50,0.15)] hover:bg-orange-50 transition-colors">
            See Demo
          </button>
        </motion.div>

        {/* Feature cards */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.5 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6 max-w-3xl w-full"
        >
          {[
            { icon: Timer, label: "Timed Tests", desc: "Per-question countdown", color: "bg-orange-100 text-orange-600" },
            { icon: Brain, label: "Bloom's Taxonomy", desc: "6 thinking levels", color: "bg-purple-100 text-purple-600" },
            { icon: BarChart2, label: "Parent Dashboard", desc: "Granular analytics", color: "bg-cyan-100 text-cyan-600" },
            { icon: Trophy, label: "Achievements", desc: "XP & streak rewards", color: "bg-yellow-100 text-yellow-600" },
          ].map(({ icon: Icon, label, desc, color }) => (
            <div key={label} className="bg-white rounded-2xl p-4 border border-[rgba(120,90,50,0.1)] text-left">
              <div className={`w-9 h-9 rounded-xl flex items-center justify-center mb-3 ${color}`}>
                <Icon size={18} />
              </div>
              <p className="font-bold text-sm text-[#1e1a14]">{label}</p>
              <p className="text-xs text-[#7c6a55] mt-0.5">{desc}</p>
            </div>
          ))}
        </motion.div>
      </div>
    </div>
  );
}

// ─── Auth ─────────────────────────────────────────────────────────────────────

function ParentAuth({ onLogin }: { onLogin: () => void }) {
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [email, setEmail] = useState("parent@example.com");
  const [password, setPassword] = useState("password123");

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#fdf6ee] to-[#fff7ed] flex items-center justify-center p-6">
      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white rounded-3xl shadow-xl border border-[rgba(120,90,50,0.1)] p-8 w-full max-w-md"
      >
        <div className="text-center mb-8">
          <span className="text-4xl">🚀</span>
          <h2
            className="text-2xl font-black mt-2 text-[#1e1a14]"
            style={{ fontFamily: "'Fredoka One', cursive" }}
          >
            BrainSpark
          </h2>
          <p className="text-[#7c6a55] text-sm mt-1">Parent Portal</p>
        </div>

        <div className="flex bg-muted rounded-xl p-1 mb-6">
          {(["login", "signup"] as const).map((m) => (
            <button
              key={m}
              onClick={() => setMode(m)}
              className={`flex-1 py-2 rounded-lg text-sm font-bold transition-all ${
                mode === m ? "bg-white shadow text-[#1e1a14]" : "text-[#7c6a55]"
              }`}
            >
              {m === "login" ? "Sign In" : "Create Account"}
            </button>
          ))}
        </div>

        <div className="space-y-4">
          {mode === "signup" && (
            <div>
              <label className="text-sm font-bold text-[#1e1a14] block mb-1.5">Full Name</label>
              <input
                className="w-full bg-[#fef9f3] border border-[rgba(120,90,50,0.15)] rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary/30"
                placeholder="Meena Sharma"
              />
            </div>
          )}
          <div>
            <label className="text-sm font-bold text-[#1e1a14] block mb-1.5">Email</label>
            <input
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-[#fef9f3] border border-[rgba(120,90,50,0.15)] rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary/30"
              type="email"
            />
          </div>
          <div>
            <label className="text-sm font-bold text-[#1e1a14] block mb-1.5">Password</label>
            <input
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-[#fef9f3] border border-[rgba(120,90,50,0.15)] rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary/30"
              type="password"
            />
          </div>
          <button
            onClick={onLogin}
            className="w-full bg-primary text-white py-3.5 rounded-xl font-bold hover:bg-orange-600 transition-colors mt-2"
          >
            {mode === "login" ? "Sign In" : "Create Account"}
          </button>
        </div>

        <p className="text-center text-xs text-[#7c6a55] mt-6">
          Demo: click Sign In to proceed instantly
        </p>
      </motion.div>
    </div>
  );
}

// ─── Add Kid ──────────────────────────────────────────────────────────────────

function AddKidView({ onBack, onAdd }: { onBack: () => void; onAdd: (kid: Kid) => void }) {
  const [name, setName] = useState("");
  const [grade, setGrade] = useState(5);
  const [avatar, setAvatar] = useState("🐻");
  const avatars = ["🐻", "🦊", "🐼", "🦁", "🐯", "🦋", "🐬", "🦄"];

  const handleAdd = () => {
    if (!name.trim()) return;
    onAdd({
      id: `k${Date.now()}`,
      name: name.trim(),
      grade,
      avatar,
      totalTests: 0,
      avgScore: 0,
      streak: 0,
      xp: 0,
    });
  };

  return (
    <div className="min-h-screen bg-[#fdf6ee] flex items-center justify-center p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-3xl shadow-xl border border-[rgba(120,90,50,0.1)] p-8 w-full max-w-md"
      >
        <button onClick={onBack} className="flex items-center gap-1 text-sm text-[#7c6a55] mb-6 hover:text-[#1e1a14]">
          <ChevronLeft size={16} /> Back
        </button>
        <h2
          className="text-2xl font-black text-[#1e1a14] mb-6"
          style={{ fontFamily: "'Fredoka One', cursive" }}
        >
          Add a Child
        </h2>

        <div className="space-y-5">
          <div>
            <label className="text-sm font-bold text-[#1e1a14] block mb-1.5">Child&apos;s Name</label>
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full bg-[#fef9f3] border border-[rgba(120,90,50,0.15)] rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-primary/30"
              placeholder="e.g. Riya"
            />
          </div>

          <div>
            <label className="text-sm font-bold text-[#1e1a14] block mb-2">Grade</label>
            <div className="flex gap-2 flex-wrap">
              {[3, 4, 5, 6, 7, 8].map((g) => (
                <button
                  key={g}
                  onClick={() => setGrade(g)}
                  className={`w-10 h-10 rounded-xl font-bold text-sm transition-all ${
                    grade === g
                      ? "bg-primary text-white shadow-md"
                      : "bg-[#fef9f3] text-[#7c6a55] border border-[rgba(120,90,50,0.15)]"
                  }`}
                >
                  {g}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-sm font-bold text-[#1e1a14] block mb-2">Pick an Avatar</label>
            <div className="flex gap-3 flex-wrap">
              {avatars.map((a) => (
                <button
                  key={a}
                  onClick={() => setAvatar(a)}
                  className={`w-12 h-12 rounded-xl text-2xl flex items-center justify-center transition-all ${
                    avatar === a
                      ? "bg-primary/10 ring-2 ring-primary"
                      : "bg-[#fef9f3] border border-[rgba(120,90,50,0.15)]"
                  }`}
                >
                  {a}
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={handleAdd}
            disabled={!name.trim()}
            className="w-full bg-primary text-white py-3.5 rounded-xl font-bold hover:bg-orange-600 transition-colors disabled:opacity-40 mt-2"
          >
            Add Child
          </button>
        </div>
      </motion.div>
    </div>
  );
}

// ─── Parent Dashboard ─────────────────────────────────────────────────────────

function ParentDashboard({
  kids,
  onSelectKid,
  onAddKid,
  onLogout,
}: {
  kids: Kid[];
  onSelectKid: (kid: Kid) => void;
  onAddKid: () => void;
  onLogout: () => void;
}) {
  return (
    <div className="min-h-screen bg-[#fdf6ee]">
      {/* Header */}
      <div className="bg-white border-b border-[rgba(120,90,50,0.1)] px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-2xl">🚀</span>
          <span className="font-black text-lg" style={{ fontFamily: "'Fredoka One', cursive" }}>
            BrainSpark
          </span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-sm text-[#7c6a55]">Welcome, Meena</span>
          <button onClick={onLogout} className="p-2 hover:bg-muted rounded-lg transition-colors">
            <LogOut size={16} className="text-[#7c6a55]" />
          </button>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 py-8">
        {/* Kids list */}
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-black text-[#1e1a14]" style={{ fontFamily: "'Fredoka One', cursive" }}>
            My Children
          </h2>
          <button
            onClick={onAddKid}
            className="flex items-center gap-2 bg-primary text-white px-4 py-2 rounded-xl text-sm font-bold hover:bg-orange-600 transition-colors"
          >
            <Plus size={16} /> Add Child
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-10">
          {kids.map((kid) => (
            <motion.div
              key={kid.id}
              whileHover={{ y: -2 }}
              className="bg-white rounded-2xl border border-[rgba(120,90,50,0.1)] p-6 cursor-pointer hover:shadow-md transition-shadow"
              onClick={() => onSelectKid(kid)}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 bg-orange-50 rounded-2xl flex items-center justify-center text-3xl">
                    {kid.avatar}
                  </div>
                  <div>
                    <p className="font-black text-lg text-[#1e1a14]">{kid.name}</p>
                    <p className="text-sm text-[#7c6a55]">Grade {kid.grade}</p>
                  </div>
                </div>
                <div className="flex items-center gap-1 bg-yellow-50 text-yellow-700 px-3 py-1 rounded-full text-sm font-bold">
                  <Zap size={13} /> {kid.xp} XP
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                {[
                  { label: "Tests", value: kid.totalTests, icon: BookOpen },
                  { label: "Avg Score", value: `${kid.avgScore}%`, icon: Target },
                  { label: "Streak", value: `${kid.streak}d`, icon: Star },
                ].map(({ label, value, icon: Icon }) => (
                  <div key={label} className="bg-[#fdf6ee] rounded-xl p-3 text-center">
                    <p className="text-xs text-[#7c6a55] mb-0.5">{label}</p>
                    <p className="font-black text-base text-[#1e1a14]">{value}</p>
                  </div>
                ))}
              </div>

              <div className="mt-4 flex items-center justify-between text-sm text-[#7c6a55]">
                <span>View full progress</span>
                <ChevronRight size={16} />
              </div>
            </motion.div>
          ))}
        </div>

        {/* Progress section for first kid */}
        {kids.length > 0 && (
          <div>
            <h3 className="text-xl font-black text-[#1e1a14] mb-5" style={{ fontFamily: "'Fredoka One', cursive" }}>
              {kids[0].name}&apos;s Progress — Last 4 Weeks
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-5 mb-5">
              {/* Score trend */}
              <div className="bg-white rounded-2xl border border-[rgba(120,90,50,0.1)] p-5">
                <p className="font-bold text-sm text-[#1e1a14] mb-4">Score Trend</p>
                <ResponsiveContainer width="100%" height={160}>
                  <LineChart data={PROGRESS_DATA}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(120,90,50,0.1)" />
                    <XAxis dataKey="week" tick={{ fontSize: 11 }} />
                    <YAxis tick={{ fontSize: 11 }} domain={[50, 100]} />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="math" stroke="#f97316" strokeWidth={2} dot={{ r: 3 }} name="Math" />
                    <Line type="monotone" dataKey="science" stroke="#06b6d4" strokeWidth={2} dot={{ r: 3 }} name="Science" />
                  </LineChart>
                </ResponsiveContainer>
              </div>

              {/* Bloom's taxonomy performance */}
              <div className="bg-white rounded-2xl border border-[rgba(120,90,50,0.1)] p-5">
                <p className="font-bold text-sm text-[#1e1a14] mb-4">Bloom&apos;s Taxonomy Levels</p>
                <ResponsiveContainer width="100%" height={160}>
                  <BarChart data={BLOOM_DATA} layout="vertical">
                    <XAxis type="number" tick={{ fontSize: 11 }} domain={[0, 100]} />
                    <YAxis dataKey="level" type="category" tick={{ fontSize: 11 }} width={80} />
                    <Tooltip />
                    <Bar dataKey="score" radius={[0, 6, 6, 0]}>
                      {BLOOM_DATA.map((entry) => (
                        <rect key={entry.level} fill={BLOOM_COLORS[entry.level] ?? "#f97316"} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Topic radar */}
            <div className="bg-white rounded-2xl border border-[rgba(120,90,50,0.1)] p-5">
              <p className="font-bold text-sm text-[#1e1a14] mb-4">Topic Mastery Map</p>
              <div className="flex flex-col md:flex-row items-center gap-6">
                <ResponsiveContainer width="100%" height={220}>
                  <RadarChart data={TOPIC_RADAR} cx="50%" cy="50%" outerRadius="70%">
                    <PolarGrid stroke="rgba(120,90,50,0.15)" />
                    <PolarAngleAxis dataKey="topic" tick={{ fontSize: 11 }} />
                    <Radar dataKey="score" stroke="#f97316" fill="#f97316" fillOpacity={0.25} />
                  </RadarChart>
                </ResponsiveContainer>
                <div className="flex flex-col gap-2 min-w-[160px]">
                  {TOPIC_RADAR.map(({ topic, score }) => (
                    <div key={topic} className="flex items-center justify-between gap-4">
                      <span className="text-xs text-[#7c6a55]">{topic}</span>
                      <div className="flex items-center gap-2">
                        <div className="w-20 h-1.5 bg-[#f5ede0] rounded-full overflow-hidden">
                          <div
                            className="h-full bg-primary rounded-full"
                            style={{ width: `${score}%` }}
                          />
                        </div>
                        <span className="text-xs font-bold text-[#1e1a14] w-8">{score}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Kid Dashboard ────────────────────────────────────────────────────────────

function KidDashboard({
  kid,
  onStartTest,
  onBack,
}: {
  kid: Kid;
  onStartTest: (subject: string, questions: Question[]) => void;
  onBack: () => void;
}) {
  const achievements = [
    { icon: "🔥", label: `${kid.streak} Day Streak`, unlocked: kid.streak >= 2 },
    { icon: "⚡", label: "Speed Demon", unlocked: kid.totalTests >= 5 },
    { icon: "🏆", label: "Top Scorer", unlocked: kid.avgScore >= 80 },
    { icon: "🔬", label: "Science Whiz", unlocked: false },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#fff7ed] to-[#fdf6ee]">
      {/* Header */}
      <div
        className="px-6 py-5 flex items-center justify-between"
        style={{ background: "linear-gradient(135deg, #f97316 0%, #fb923c 100%)" }}
      >
        <button onClick={onBack} className="p-2 bg-white/20 rounded-xl hover:bg-white/30 transition-colors">
          <ChevronLeft size={18} className="text-white" />
        </button>
        <div className="text-center">
          <p className="text-white/80 text-xs font-bold tracking-widest uppercase">Grade {kid.grade}</p>
          <p className="text-white font-black text-xl" style={{ fontFamily: "'Fredoka One', cursive" }}>
            {kid.avatar} Hey, {kid.name}!
          </p>
        </div>
        <div className="flex items-center gap-1 bg-white/20 rounded-xl px-3 py-1.5">
          <Zap size={14} className="text-yellow-200" />
          <span className="text-white text-sm font-black">{kid.xp}</span>
        </div>
      </div>

      <div className="max-w-lg mx-auto px-5 py-6 space-y-6">
        {/* XP progress */}
        <div className="bg-white rounded-2xl p-4 border border-[rgba(120,90,50,0.1)]">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-bold text-[#1e1a14]">Level {Math.floor(kid.xp / 500) + 1}</span>
            <span className="text-xs text-[#7c6a55]">{kid.xp % 500} / 500 XP</span>
          </div>
          <div className="h-3 bg-[#f5ede0] rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${(kid.xp % 500) / 5}%` }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              className="h-full bg-gradient-to-r from-orange-400 to-orange-500 rounded-full"
            />
          </div>
        </div>

        {/* Choose subject */}
        <div>
          <h3 className="font-black text-lg text-[#1e1a14] mb-3" style={{ fontFamily: "'Fredoka One', cursive" }}>
            Pick a Challenge
          </h3>
          <div className="grid grid-cols-2 gap-3">
            {SUBJECT_CONFIGS.map(({ id, label, icon: Icon, color, bg, questions }) => (
              <motion.button
                key={id}
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
                onClick={() => onStartTest(label, questions)}
                className={`${bg} rounded-2xl p-5 text-left border border-[rgba(120,90,50,0.08)] hover:shadow-md transition-shadow`}
              >
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center mb-3"
                  style={{ backgroundColor: `${color}20` }}
                >
                  <Icon size={22} style={{ color }} />
                </div>
                <p className="font-black text-sm text-[#1e1a14]">{label}</p>
                <p className="text-xs text-[#7c6a55] mt-0.5">{questions.length} questions</p>
                <div className="mt-3 flex items-center gap-1 text-xs font-bold" style={{ color }}>
                  Start <ChevronRight size={12} />
                </div>
              </motion.button>
            ))}
          </div>
        </div>

        {/* Achievements */}
        <div>
          <h3 className="font-black text-lg text-[#1e1a14] mb-3" style={{ fontFamily: "'Fredoka One', cursive" }}>
            Achievements
          </h3>
          <div className="grid grid-cols-2 gap-3">
            {achievements.map(({ icon, label, unlocked }) => (
              <div
                key={label}
                className={`flex items-center gap-3 rounded-2xl p-3 border ${
                  unlocked
                    ? "bg-white border-[rgba(120,90,50,0.1)]"
                    : "bg-[#f5ede0] border-transparent opacity-50"
                }`}
              >
                <span className="text-2xl">{icon}</span>
                <p className="text-xs font-bold text-[#1e1a14]">{label}</p>
                {unlocked && <Check size={14} className="ml-auto text-green-500 shrink-0" />}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Practice Test ────────────────────────────────────────────────────────────

function PracticeTest({
  subject,
  questions,
  onComplete,
  onBack,
}: {
  subject: string;
  questions: Question[];
  onComplete: (results: TestResult[]) => void;
  onBack: () => void;
}) {
  const [current, setCurrent] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [confirmed, setConfirmed] = useState(false);
  const [timeLeft, setTimeLeft] = useState(questions[0].timeAllotted);
  const [questionStartTime, setQuestionStartTime] = useState(Date.now());
  const [results, setResults] = useState<TestResult[]>([]);

  const q = questions[current];

  const handleNext = useCallback(
    (chosenOption: number | null) => {
      const timeTaken = Math.round((Date.now() - questionStartTime) / 1000);
      const isCorrect = chosenOption === q.correct;
      const newResults = [
        ...results,
        {
          questionId: q.id,
          selected: chosenOption,
          correct: isCorrect,
          timeTaken,
          topic: q.topic,
          bloomLevel: q.bloomLevel,
        },
      ];

      if (current + 1 < questions.length) {
        setResults(newResults);
        setCurrent(current + 1);
        setSelected(null);
        setConfirmed(false);
        setTimeLeft(questions[current + 1].timeAllotted);
        setQuestionStartTime(Date.now());
      } else {
        onComplete(newResults);
      }
    },
    [current, q, questionStartTime, questions, results, onComplete]
  );

  useEffect(() => {
    if (confirmed) return;
    if (timeLeft <= 0) {
      handleNext(selected);
      return;
    }
    const t = setTimeout(() => setTimeLeft((s) => s - 1), 1000);
    return () => clearTimeout(t);
  }, [timeLeft, confirmed, selected, handleNext]);

  const pct = (timeLeft / q.timeAllotted) * 100;
  const timerColor = pct > 50 ? "#22c55e" : pct > 25 ? "#f59e0b" : "#dc2626";

  return (
    <div className="min-h-screen bg-[#fdf6ee] flex flex-col">
      {/* Top bar */}
      <div className="bg-white border-b border-[rgba(120,90,50,0.1)] px-5 py-3 flex items-center gap-4">
        <button onClick={onBack} className="p-1.5 hover:bg-muted rounded-lg transition-colors">
          <X size={16} className="text-[#7c6a55]" />
        </button>
        <div className="flex-1">
          <div className="flex items-center justify-between text-xs text-[#7c6a55] mb-1">
            <span className="font-bold">{subject}</span>
            <span>{current + 1} / {questions.length}</span>
          </div>
          <div className="h-1.5 bg-[#f5ede0] rounded-full overflow-hidden">
            <div
              className="h-full bg-primary rounded-full transition-all"
              style={{ width: `${((current) / questions.length) * 100}%` }}
            />
          </div>
        </div>
        {/* Timer */}
        <div
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-black text-sm tabular-nums"
          style={{ backgroundColor: `${timerColor}18`, color: timerColor }}
        >
          <Timer size={14} />
          {timeLeft}s
        </div>
      </div>

      <div className="flex-1 flex flex-col max-w-lg mx-auto w-full px-5 py-6 gap-5">
        {/* Meta badges */}
        <div className="flex gap-2 flex-wrap">
          <Badge label={q.topic} color="#7c6a55" />
          <Badge label={q.bloomLevel} color={BLOOM_COLORS[q.bloomLevel]} />
          <Badge label={q.difficulty} color={q.difficulty === "Easy" ? "#22c55e" : q.difficulty === "Medium" ? "#f59e0b" : "#dc2626"} />
        </div>

        {/* Question */}
        <div className="bg-white rounded-2xl border border-[rgba(120,90,50,0.1)] p-6">
          <p className="text-base font-bold text-[#1e1a14] leading-relaxed">{q.question}</p>
        </div>

        {/* Options */}
        <div className="space-y-3 flex-1">
          {q.options.map((opt, i) => {
            let state: "default" | "selected" | "correct" | "wrong" = "default";
            if (confirmed) {
              if (i === q.correct) state = "correct";
              else if (i === selected && selected !== q.correct) state = "wrong";
            } else if (i === selected) {
              state = "selected";
            }

            const stateClasses = {
              default: "bg-white border-[rgba(120,90,50,0.12)] hover:border-primary hover:bg-orange-50",
              selected: "bg-orange-50 border-primary",
              correct: "bg-green-50 border-green-500",
              wrong: "bg-red-50 border-red-400",
            }[state];

            return (
              <motion.button
                key={i}
                whileTap={{ scale: 0.99 }}
                disabled={confirmed}
                onClick={() => setSelected(i)}
                className={`w-full flex items-center gap-3 border-2 rounded-xl px-4 py-3.5 text-left transition-all ${stateClasses}`}
              >
                <span
                  className="w-7 h-7 rounded-lg flex items-center justify-center text-xs font-black shrink-0"
                  style={{
                    backgroundColor:
                      state === "correct" ? "#22c55e" :
                      state === "wrong" ? "#dc2626" :
                      state === "selected" ? "#f97316" : "#f5ede0",
                    color: state !== "default" ? "white" : "#7c6a55",
                  }}
                >
                  {["A", "B", "C", "D"][i]}
                </span>
                <span className="font-medium text-sm text-[#1e1a14]">{opt}</span>
                {state === "correct" && <Check size={16} className="ml-auto text-green-500 shrink-0" />}
                {state === "wrong" && <X size={16} className="ml-auto text-red-400 shrink-0" />}
              </motion.button>
            );
          })}
        </div>

        {/* Action button */}
        <div>
          {!confirmed ? (
            <button
              onClick={() => { if (selected !== null) setConfirmed(true); }}
              disabled={selected === null}
              className="w-full bg-primary text-white py-4 rounded-xl font-black hover:bg-orange-600 transition-colors disabled:opacity-40"
            >
              Confirm Answer
            </button>
          ) : (
            <button
              onClick={() => handleNext(selected)}
              className="w-full bg-[#1e1a14] text-white py-4 rounded-xl font-black hover:bg-[#2d2820] transition-colors flex items-center justify-center gap-2"
            >
              {current + 1 < questions.length ? "Next Question" : "See Results"}
              <ChevronRight size={18} />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Test Results ─────────────────────────────────────────────────────────────

function TestResults({
  subject,
  questions,
  results,
  onBack,
  onRetry,
}: {
  subject: string;
  questions: Question[];
  results: TestResult[];
  onBack: () => void;
  onRetry: () => void;
}) {
  const correct = results.filter((r) => r.correct).length;
  const score = Math.round((correct / results.length) * 100);
  const totalTime = results.reduce((a, r) => a + r.timeTaken, 0);
  const avgTime = Math.round(totalTime / results.length);

  const topicBreakdown: Record<string, { correct: number; total: number; time: number }> = {};
  results.forEach((r) => {
    if (!topicBreakdown[r.topic]) topicBreakdown[r.topic] = { correct: 0, total: 0, time: 0 };
    topicBreakdown[r.topic].total++;
    topicBreakdown[r.topic].time += r.timeTaken;
    if (r.correct) topicBreakdown[r.topic].correct++;
  });

  const bloomBreakdown: Record<string, { correct: number; total: number }> = {};
  results.forEach((r) => {
    if (!bloomBreakdown[r.bloomLevel]) bloomBreakdown[r.bloomLevel] = { correct: 0, total: 0 };
    bloomBreakdown[r.bloomLevel].total++;
    if (r.correct) bloomBreakdown[r.bloomLevel].correct++;
  });

  const scoreEmoji = score >= 90 ? "🏆" : score >= 75 ? "🌟" : score >= 60 ? "👍" : "💪";

  return (
    <div className="min-h-screen bg-[#fdf6ee]">
      <div className="max-w-lg mx-auto px-5 py-6 space-y-5">
        {/* Score hero */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-gradient-to-br from-[#f97316] to-[#fb923c] rounded-3xl p-7 text-center text-white"
        >
          <div className="text-5xl mb-2">{scoreEmoji}</div>
          <div className="text-6xl font-black mb-1">{score}%</div>
          <p className="text-white/80 text-sm">{correct} / {results.length} correct · {subject}</p>

          <div className="grid grid-cols-3 gap-3 mt-6">
            {[
              { label: "Total Time", value: formatTime(totalTime) },
              { label: "Avg / Q", value: formatTime(avgTime) },
              { label: "Accuracy", value: `${score}%` },
            ].map(({ label, value }) => (
              <div key={label} className="bg-white/20 rounded-xl py-2 px-1">
                <p className="text-xs text-white/70">{label}</p>
                <p className="font-black text-base">{value}</p>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Topic breakdown */}
        <div className="bg-white rounded-2xl border border-[rgba(120,90,50,0.1)] p-5">
          <p className="font-black text-sm text-[#1e1a14] mb-4">Topic Breakdown</p>
          <div className="space-y-3">
            {Object.entries(topicBreakdown).map(([topic, data]) => {
              const pct = Math.round((data.correct / data.total) * 100);
              return (
                <div key={topic}>
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="font-bold text-[#1e1a14]">{topic}</span>
                    <div className="flex items-center gap-3 text-[#7c6a55]">
                      <span className="flex items-center gap-1"><Clock size={10} /> {formatTime(Math.round(data.time / data.total))} avg</span>
                      <span className="font-bold text-[#1e1a14]">{pct}%</span>
                    </div>
                  </div>
                  <div className="h-2 bg-[#f5ede0] rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all"
                      style={{
                        width: `${pct}%`,
                        backgroundColor: pct >= 80 ? "#22c55e" : pct >= 60 ? "#f59e0b" : "#dc2626",
                      }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Bloom level performance */}
        <div className="bg-white rounded-2xl border border-[rgba(120,90,50,0.1)] p-5">
          <p className="font-black text-sm text-[#1e1a14] mb-4">Bloom&apos;s Taxonomy Performance</p>
          <div className="flex gap-2 flex-wrap">
            {Object.entries(bloomBreakdown).map(([level, data]) => {
              const pct = Math.round((data.correct / data.total) * 100);
              return (
                <div
                  key={level}
                  className="flex-1 min-w-[80px] rounded-xl p-3 text-center"
                  style={{ backgroundColor: `${BLOOM_COLORS[level]}15` }}
                >
                  <p className="text-xs font-bold" style={{ color: BLOOM_COLORS[level] }}>{level}</p>
                  <p className="text-xl font-black text-[#1e1a14]">{pct}%</p>
                  <p className="text-xs text-[#7c6a55]">{data.correct}/{data.total}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Per-question review */}
        <div className="bg-white rounded-2xl border border-[rgba(120,90,50,0.1)] p-5">
          <p className="font-black text-sm text-[#1e1a14] mb-4">Question Review</p>
          <div className="space-y-3">
            {results.map((r, i) => {
              const q = questions.find((q) => q.id === r.questionId)!;
              return (
                <div key={r.questionId} className="flex items-start gap-3">
                  <div
                    className="w-7 h-7 rounded-full flex items-center justify-center shrink-0 mt-0.5"
                    style={{ backgroundColor: r.correct ? "#22c55e" : "#dc2626" }}
                  >
                    {r.correct ? <Check size={13} className="text-white" /> : <X size={13} className="text-white" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-bold text-[#1e1a14] truncate">Q{i + 1}: {q.question}</p>
                    {!r.correct && r.selected !== null && (
                      <p className="text-xs text-red-500 mt-0.5">
                        Your answer: {q.options[r.selected]} · Correct: {q.options[q.correct]}
                      </p>
                    )}
                  </div>
                  <span className="text-xs text-[#7c6a55] shrink-0 flex items-center gap-1">
                    <Clock size={10} /> {r.timeTaken}s
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Actions */}
        <div className="grid grid-cols-2 gap-3 pb-4">
          <button
            onClick={onRetry}
            className="flex items-center justify-center gap-2 bg-primary text-white py-3.5 rounded-xl font-bold hover:bg-orange-600 transition-colors"
          >
            <Zap size={16} /> Try Again
          </button>
          <button
            onClick={onBack}
            className="flex items-center justify-center gap-2 bg-white text-[#1e1a14] py-3.5 rounded-xl font-bold border border-[rgba(120,90,50,0.15)] hover:bg-orange-50 transition-colors"
          >
            <ArrowRight size={16} /> Dashboard
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── App ──────────────────────────────────────────────────────────────────────

export default function App() {
  const [view, setView] = useState<View>("landing");
  const [kids, setKids] = useState<Kid[]>(KIDS);
  const [selectedKid, setSelectedKid] = useState<Kid | null>(null);
  const [activeSubject, setActiveSubject] = useState("");
  const [activeQuestions, setActiveQuestions] = useState<Question[]>([]);
  const [testResults, setTestResults] = useState<TestResult[]>([]);

  const handleLogin = () => setView("parent-dashboard");
  const handleLogout = () => setView("landing");

  const handleSelectKid = (kid: Kid) => {
    setSelectedKid(kid);
    setView("kid-dashboard");
  };

  const handleStartTest = (subject: string, questions: Question[]) => {
    setActiveSubject(subject);
    setActiveQuestions(questions);
    setView("practice-test");
  };

  const handleTestComplete = (results: TestResult[]) => {
    setTestResults(results);
    setView("test-results");
    if (selectedKid) {
      const correct = results.filter((r) => r.correct).length;
      const score = Math.round((correct / results.length) * 100);
      setKids((prev) =>
        prev.map((k) =>
          k.id === selectedKid.id
            ? {
                ...k,
                totalTests: k.totalTests + 1,
                avgScore: Math.round((k.avgScore * k.totalTests + score) / (k.totalTests + 1)),
                xp: k.xp + correct * 50 + (score >= 80 ? 100 : 0),
                streak: k.streak + (score >= 60 ? 1 : 0),
              }
            : k
        )
      );
    }
  };

  const handleAddKid = (kid: Kid) => {
    setKids((prev) => [...prev, kid]);
    setView("parent-dashboard");
  };

  return (
    <div
      className="size-full overflow-y-auto"
      style={{ fontFamily: "'Nunito', sans-serif", scrollbarWidth: "none" }}
    >
      <style>{`::-webkit-scrollbar { display: none; }`}</style>
      <AnimatePresence mode="wait">
        {view === "landing" && (
          <motion.div key="landing" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <LandingView onEnter={() => setView("parent-auth")} />
          </motion.div>
        )}
        {view === "parent-auth" && (
          <motion.div key="auth" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <ParentAuth onLogin={handleLogin} />
          </motion.div>
        )}
        {view === "parent-dashboard" && (
          <motion.div key="parent-dash" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <ParentDashboard
              kids={kids}
              onSelectKid={handleSelectKid}
              onAddKid={() => setView("add-kid")}
              onLogout={handleLogout}
            />
          </motion.div>
        )}
        {view === "add-kid" && (
          <motion.div key="add-kid" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <AddKidView onBack={() => setView("parent-dashboard")} onAdd={handleAddKid} />
          </motion.div>
        )}
        {view === "kid-dashboard" && selectedKid && (
          <motion.div key="kid-dash" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <KidDashboard
              kid={selectedKid}
              onStartTest={handleStartTest}
              onBack={() => setView("parent-dashboard")}
            />
          </motion.div>
        )}
        {view === "practice-test" && (
          <motion.div key="test" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <PracticeTest
              subject={activeSubject}
              questions={activeQuestions}
              onComplete={handleTestComplete}
              onBack={() => setView("kid-dashboard")}
            />
          </motion.div>
        )}
        {view === "test-results" && (
          <motion.div key="results" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <TestResults
              subject={activeSubject}
              questions={activeQuestions}
              results={testResults}
              onBack={() => setView("kid-dashboard")}
              onRetry={() => {
                setView("practice-test");
              }}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
